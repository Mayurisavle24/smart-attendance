</div>
<footer style="text-align: center; padding: 20px; font-size: 13px; color: #666; margin-top: 40px; border-top: 1px solid #ddd;">
    <p><strong>Vivekanand Arts, Sardar Dalipsingh Commerce and Science College</strong></p>
    <p>Samarth Nagar, Chhatrapati Sambhaji Nagar (Aurangabad) - 431001 (M.S.) India</p>
    <p>Email: <a href="mailto:info@vivekanandcollege.edu.in" style="color:var(--primary-color);">info@vivekanandcollege.edu.in</a> | Phone: (0240) 2365802</p>
    <p style="margin-top:10px;">&copy; <?php echo date("Y"); ?> All Rights Reserved.</p>
</footer>
</body>
</html>
